/**
 * @preserve date-and-time.js locale configuration
 * @preserve Englis (en)
 * @preserve This is a dummy module.
 */

var en = function (date) {
    var code = 'en';

    return code;
};

export default en;
