export default function (proto: unknown, date?: unknown): string;
