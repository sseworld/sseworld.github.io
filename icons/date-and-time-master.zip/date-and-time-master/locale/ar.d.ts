export default function (date: unknown): string;
